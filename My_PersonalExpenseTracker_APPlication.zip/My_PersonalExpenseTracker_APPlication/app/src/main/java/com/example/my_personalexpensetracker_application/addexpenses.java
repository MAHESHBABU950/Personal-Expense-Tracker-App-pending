package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;


public class addexpenses extends AppCompatActivity {
    private EditText etAmount, etCategory, etDescription;
    private DatabaseReference dbRef;
    Button btnSaveExpense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addexpenses);

        dbRef = FirebaseDatabase.getInstance().getReference("expenses");
        etAmount = findViewById(R.id.et_amount);
        etCategory = findViewById(R.id.et_category);
        etDescription = findViewById(R.id.et_description);
        btnSaveExpense = findViewById(R.id.btn_save);

//        EditText etAmount = findViewById(R.id.et_amount);
//        EditText etCategory = findViewById(R.id.et_category);
//        EditText etDescription = findViewById(R.id.et_description);
//        Button btnSave = findViewById(R.id.btn_save_expense);

        btnSaveExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = etAmount.getText().toString();
                String category = etCategory.getText().toString();
                String description = etDescription.getText().toString();

                if (!amount.isEmpty() && !category.isEmpty() && !description.isEmpty()) {
                    Toast.makeText(addexpenses.this, "Expense Saved", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to the previous page
                } else {
                    Toast.makeText(addexpenses.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}