package com.example.my_personalexpensetracker_application;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;

public class addexpenses extends AppCompatActivity {

    private EditText etName, etAmount, etDate, etCategory, etDescription;
    private Button btnSaveExpense;
    private ImageView backButton, dotsIcon;
    private TextView titleTextView;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addexpenses);

        // Initialize Firebase
        dbRef = FirebaseDatabase.getInstance().getReference("expenses");

        // Initialize Views
        etName = findViewById(R.id.nameEditText); // Assuming these IDs are present in the XML
        etAmount = findViewById(R.id.amountEditText);
        etDate = findViewById(R.id.et_date);
        etCategory = findViewById(R.id.et_category); // Add to XML layout
        etDescription = findViewById(R.id.et_description); // Add to XML layout
        btnSaveExpense = findViewById(R.id.saveExpenseButton);
        backButton = findViewById(R.id.imageView8);
        dotsIcon = findViewById(R.id.imageView12);
        titleTextView = findViewById(R.id.textView9);

        // Back Button Click
        backButton.setOnClickListener(v -> onBackPressed());

        // Dots Icon Click (for menu or options)
        dotsIcon.setOnClickListener(v ->
                Toast.makeText(this, "Options menu clicked", Toast.LENGTH_SHORT).show()
        );

        // Date Picker for Date EditText
        etDate.setOnClickListener(v -> showDatePicker());

        // Save Expense Button Click
        btnSaveExpense.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String amount = etAmount.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String category = etCategory.getText().toString().trim();
            String description = etDescription.getText().toString().trim();

            if (name.isEmpty() || amount.isEmpty() || date.isEmpty() || category.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            } else if (!amount.matches("\\d+(\\.\\d+)?")) { // Check if the amount is a valid number
                Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show();
            } else {
                saveExpenseToFirebase(name, amount, date, category, description);
            }
        });

    }

    /**
     * Shows a DatePickerDialog to select a date.
     */
    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, month1, dayOfMonth) -> {
                    String selectedDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
                    etDate.setText(selectedDate);
                }, year, month, day);
        datePickerDialog.show();
    }

    /**
     * Saves the expense details to Firebase.
     */
    private void saveExpenseToFirebase(String name, String amount, String date, String category, String description) {
        String expenseId = dbRef.push().getKey(); // Generate unique ID for the expense

        if (expenseId != null) {
            HashMap<String, Object> expenseData = new HashMap<>();
            expenseData.put("id", expenseId);
            expenseData.put("name", name);
            expenseData.put("amount", amount);
            expenseData.put("date", date);
            expenseData.put("category", category);
            expenseData.put("description", description);

            dbRef.child(expenseId).setValue(expenseData)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(addexpenses.this, "Expense Saved Successfully", Toast.LENGTH_SHORT).show();
                        // Navigate to homepage
                        Intent intent = new Intent(addexpenses.this, mainhomepageFragment.class);
                        startActivity(intent);

                        // Finish current activity to prevent returning to it
                        finish(); // Navigate back
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(addexpenses.this, "Failed to save expense: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );
        }
    }
}
