package com.example.my_personalexpensetracker_application;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import java.text.DecimalFormat;

public class walletFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private ImageView addImageView;

    public walletFragment() {
        // Required empty public constructor
    }

    public static walletFragment newInstance(String param1, String param2) {
        walletFragment fragment = new walletFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_wallet, container, false);

        // Initialize views
        addImageView = rootView.findViewById(R.id.addImageView);

        // Set click listeners
        rootView.findViewById(R.id.shareImageView).setOnClickListener(v -> shareTransactionDetails(123456789));
        addImageView.setOnClickListener(v -> showAddCardDialog());

        // Display total balance
        TextView amountTextView = rootView.findViewById(R.id.amountTextView);
        long amount = 123456789; // Example amount, replace with dynamic data
        DecimalFormat formatter = new DecimalFormat("#,###");
        amountTextView.setText(formatter.format(amount));

        return rootView;
    }

    private void showAddCardDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add Card or Bank Account");

        // Layout for dialog input
        LinearLayout layout = new LinearLayout(getContext());
        layout.setOrientation(LinearLayout.VERTICAL);

        // Input field
        final EditText editText = new EditText(getContext());
        editText.setHint("Enter card number or bank account");
        layout.addView(editText);

        builder.setView(layout);
        builder.setPositiveButton("Add", (dialog, id) -> {
            String input = editText.getText().toString();
            if (!input.isEmpty()) {
                Toast.makeText(getContext(), "Card/Bank Account added: " + input, Toast.LENGTH_SHORT).show();
                // Add logic to store the card/bank account
            } else {
                Toast.makeText(getContext(), "Please enter a valid account or card number", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void shareTransactionDetails(long amount) {
        String transactionDetails = "Transaction Details:\n" +
                "---------------------------\n" +
                "Wallet Balance: ₹" + new DecimalFormat("#,###").format(amount) + "\n" +
                "Transaction ID: TXN" + System.currentTimeMillis() + "\n" +
                "Date: " + java.text.DateFormat.getDateTimeInstance().format(System.currentTimeMillis()) + "\n";

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, transactionDetails);

        try {
            startActivity(Intent.createChooser(shareIntent, "Share Transaction Details"));
        } catch (Exception e) {
            Toast.makeText(getContext(), "No suitable app found to share details.", Toast.LENGTH_SHORT).show();
        }
    }
}
