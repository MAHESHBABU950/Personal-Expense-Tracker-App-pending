package com.example.my_personalexpensetracker_application;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class mainhomepage_btmnav extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainhomepage_btmnav);

        // Set up FloatingActionButton to add expense
        FloatingActionButton fabAddExpense = findViewById(R.id.fab_add_expense);
        fabAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddExpense Activity
                Intent intent = new Intent(mainhomepage_btmnav.this, addexpenses.class);
                startActivity(intent);
            }
        });

        // Set up BottomNavigationView
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setBackground(null);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.btm_home) {
                    openFragment(new mainhomepageFragment());
                } else if (itemId == R.id.btm_statics) {
                    openFragment(new statisticsFragment());
                } else if (itemId == R.id.btm_wallet) {
                    openFragment(new walletFragment());
                } else if (itemId == R.id.btm_profile) {
                    openFragment(new profileFragment());
                }
                return false;
            }
        });


        // Initialize FragmentManager
        fragmentManager = getSupportFragmentManager();

        // Optionally, you can set the default fragment to be displayed
        if (savedInstanceState == null) {
            openFragment(new mainhomepageFragment());
            // Opens the main homepage fragment as the first page
        }
    }

    private void openFragment(Fragment fragment) {
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)  // Replace the current fragment with the new one
                .commit();  // Commit the transaction to show the fragment
    }

}
