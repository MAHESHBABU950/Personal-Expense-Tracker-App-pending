package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class loginpage extends AppCompatActivity {
    ImageView imageviewbtn;
    TextView textview1,textview2,textview3,textview5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        imageviewbtn = findViewById(R.id.imageView7);
        textview5 = findViewById(R.id.textView5);

        // Set click listener on text view 3 to move to next page
        textview5.setOnClickListener(v -> {
            Intent intent = new Intent(loginpage.this, main_loginpage1.class);
            startActivity(intent);
            finish();
        });

        // Set click listener on the image view to move to next page
        imageviewbtn.setOnClickListener(v -> {
            Intent intent = new Intent(loginpage.this, registerpage.class);
            startActivity(intent);
            finish();
        });
    }
}