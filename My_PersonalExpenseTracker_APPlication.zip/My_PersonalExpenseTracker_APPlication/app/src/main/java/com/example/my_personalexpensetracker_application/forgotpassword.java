package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.widget.LinearLayout;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class forgotpassword extends AppCompatActivity {

    // UI Elements
    EditText phoneNumberInput;
    TextView digit1, digit2, digit3, digit4, digit5, digit6, resendTextView;
    private String phoneNumber;
    private FirebaseAuth mAuth;
    private String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Initialize Views
        phoneNumberInput = findViewById(R.id.phone_number);
        digit1 = findViewById(R.id.digit_1);
        digit2 = findViewById(R.id.digit_2);
        digit3 = findViewById(R.id.digit_3);
        digit4 = findViewById(R.id.digit_4);
        digit5 = findViewById(R.id.digit_5);
        digit6 = findViewById(R.id.digit_6);
        resendTextView = findViewById(R.id.resend_text);

        // Handle Phone Number Input
        phoneNumberInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable editable) {
                phoneNumber = phoneNumberInput.getText().toString();
            }
        });

        // Set up OTP Text Watchers for each digit field
        setupOtpFields();

        // Resend OTP TextView click listener
        resendTextView.setOnClickListener(v -> resendOtp(phoneNumber));
    }

    private void setupOtpFields() {
        digit1.addTextChangedListener(createOtpTextWatcher(digit2));
        digit2.addTextChangedListener(createOtpTextWatcher(digit3));
        digit3.addTextChangedListener(createOtpTextWatcher(digit4));
        digit4.addTextChangedListener(createOtpTextWatcher(digit5));
        digit5.addTextChangedListener(createOtpTextWatcher(digit6));
    }

    private TextWatcher createOtpTextWatcher(final TextView nextField) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() == 1 && nextField != null) {
                    nextField.requestFocus();
                }
            }
        };
    }

    // Resend OTP functionality
    private void resendOtp(String phoneNumber) {
        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send OTP via Firebase
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber, // Phone number
                60,  // Timeout duration
                java.util.concurrent.TimeUnit.SECONDS,
                this, // Activity context
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
                        // Handle OTP auto-retrieval success
                    }

                    @Override
                    public void onVerificationFailed(FirebaseException e) {  // Updated method signature
                        Toast.makeText(forgotpassword.this, "Verification Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onCodeSent(String verificationId, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        // Save the verification ID for manual entry
                        forgotpassword.this.verificationId = verificationId;
                    }
                });

    }

    // Verify OTP
    private void verifyOtp(String otp) {
        // Assuming verification ID is stored
        String verificationId = "yourVerificationId"; // Replace with actual verification ID

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, otp);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                // OTP verified successfully
                Toast.makeText(forgotpassword.this, "OTP Verified", Toast.LENGTH_SHORT).show();

                // Start the Main Home Page activity
                Intent intent = new Intent(forgotpassword.this, mainhomepage.class);  // Replace MainHomePage with your actual class name
                startActivity(intent);
                finish(); // Optional: Close the current activity so the user can't go back to the forgot password screen
            } else {
                // OTP verification failed
                Toast.makeText(forgotpassword.this, "OTP Verification Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
