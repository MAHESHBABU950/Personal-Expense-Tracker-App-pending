package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class homepage extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private Toolbar toolbarHome;
    private ImageView image;
    private TextView text2, text, textView, textView2, textView3;
    private BottomAppBar bottomAppBar;
    private BottomNavigationView bottomNavigationView;
    private CoordinatorLayout coordinatorLayout;
    private FragmentManager fragmentManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        // Initialize the DrawerLayout
        drawerLayout = findViewById(R.id.main);

        // Initialize the Toolbar
        toolbarHome = findViewById(R.id.toolbarHome);
        setSupportActionBar(toolbarHome); // Set the toolbar as the action bar

        // Initialize the ImageView and TextViews inside the Toolbar
        image = findViewById(R.id.image);
        text2 = findViewById(R.id.text2);
        text = findViewById(R.id.text);
        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);

        // Set the image and text content (if needed)
        image.setImageResource(R.drawable.logo); // Ensure this drawable exists
        text2.setText("Raja Kumar");
        text.setText("HT.NO");
        textView.setText("20M65A0511");
        textView2.setText("Branch");
        textView3.setText("CSE");

        // Initialize the CoordinatorLayout and BottomAppBar
        coordinatorLayout = findViewById(R.id.coordinatorLayout); // Correct id
        bottomAppBar = findViewById(R.id.bottomAppBar);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Set the BottomNavigationView to handle item selection
        bottomNavigationView.setBackground(null);
        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.btm_home) {
                    openFragment(new mainhomepageFragment());
                } else if (itemId == R.id.btm_statics) {
                    openFragment(new statisticsFragment());
                } else if (itemId == R.id.btm_wallet) {
                    openFragment(new walletFragment());
                } else if (itemId == R.id.btm_profile) {
                    openFragment(new profileFragment());
                }
                return true;
            }
        });

        // Initialize the FragmentManager
        fragmentManager = getSupportFragmentManager();
        openFragment(new mainhomepageFragment()); // Open home fragment initially
    }

    private void openFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }
}
