package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import androidx.appcompat.app.AppCompatActivity;

public class notifications extends AppCompatActivity {
    private TextView notificationsTextView;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        notificationsTextView = findViewById(R.id.notificationsTextView);  // Define TextView in your layout
        databaseReference = FirebaseDatabase.getInstance().getReference("notifications");

        // Fetch notifications from Firebase
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                StringBuilder notifications = new StringBuilder();

                for (DataSnapshot notificationSnapshot : dataSnapshot.getChildren()) {
                    String title = notificationSnapshot.child("title").getValue(String.class);
                    String message = notificationSnapshot.child("message").getValue(String.class);

                    notifications.append("Title: ").append(title).append("\n");
                    notifications.append("Message: ").append(message).append("\n\n");
                }

                // Display notifications in TextView
                notificationsTextView.setText(notifications.toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
            }
        });
    }
}
