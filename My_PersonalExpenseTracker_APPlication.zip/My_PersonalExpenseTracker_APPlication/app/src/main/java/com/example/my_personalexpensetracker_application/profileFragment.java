package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

public class profileFragment extends Fragment {

    private ImageView imageView, imageView2, imageView3, imageView4, imageView5, imageView6, imageView7;
    private TextView textView1, textView2, textView3, textView4, textView5, textView6, textView7, textView8;

    @Override
    public void onResume() {
        super.onResume();
        Toolbar toolbar = requireActivity().findViewById(R.id.toolbarHome);
        if (toolbar != null) {
            toolbar.setVisibility(View.GONE);
        }
    }//for removing the display of home_dashboardfragment toolbar

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize ImageView and TextView
        imageView = view.findViewById(R.id.imageView);
        imageView2 = view.findViewById(R.id.imageView2);
        imageView3 = view.findViewById(R.id.imageView3);
        imageView4 = view.findViewById(R.id.imageView4);
        imageView5 = view.findViewById(R.id.imageView5);
        imageView6 = view.findViewById(R.id.imageView6);
        imageView7 = view.findViewById(R.id.imageView7);

        textView1 = view.findViewById(R.id.textview1);
        textView2 = view.findViewById(R.id.textview2);
        textView3 = view.findViewById(R.id.textview3);
        textView4 = view.findViewById(R.id.textview4);
        textView5 = view.findViewById(R.id.textview5);
        textView6 = view.findViewById(R.id.textview6);
        textView7 = view.findViewById(R.id.textview7);
        textView8 = view.findViewById(R.id.textview8);

        // Set the text for TextViews if needed
        textView1.setText("Uday Kiran");
        textView2.setText("udayuppati@gmail.com");
        textView3.setText("Invite Friends");
        textView4.setText("Account Info");
        textView5.setText("Personal Profile");
        textView6.setText("Message Center");
        textView7.setText("Login and Security");
        textView8.setText("Data and Privacy");

        return view;
    }
}
