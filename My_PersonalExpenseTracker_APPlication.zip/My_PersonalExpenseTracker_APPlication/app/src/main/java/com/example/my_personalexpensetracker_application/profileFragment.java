package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class profileFragment extends Fragment {

    private ImageView imageView;  // Main profile image
    private TextView textView1, textView2, textView3, textView4, textView5, textView6, textView7, textView8;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize ImageView and TextView
        imageView = view.findViewById(R.id.imageView);
        textView1 = view.findViewById(R.id.textview1);
        textView2 = view.findViewById(R.id.textview2);
        textView3 = view.findViewById(R.id.textview3);
        textView4 = view.findViewById(R.id.textview4);
        textView5 = view.findViewById(R.id.textview5);
        textView6 = view.findViewById(R.id.textview6);
        textView7 = view.findViewById(R.id.textview7);
        textView8 = view.findViewById(R.id.textview8);

        // Assume you have user data here (e.g., from registration page or API response)
        String userName = "Uday Kiran";  // Example dynamic data
        String userEmail = "udayuppati@gmail.com";  // Example dynamic data
        String profileImageUrl = "https://example.com/user_profile.jpg";  // Example dynamic image URL

        // Set the text for TextViews dynamically
        textView1.setText(userName);
        textView2.setText(userEmail);

        // Optionally, load the profile image dynamically using a library like Glide or Picasso
        // Glide.with(getContext()).load(profileImageUrl).into(imageView);
        // Or set a default image if none is available:
        imageView.setImageResource(R.drawable.profile_logo);  // Use a placeholder or default image

        // Optionally, update the other TextViews as per the user flow
        textView3.setOnClickListener(v -> navigateToFragment(new invitefrndsFragment()));
        textView4.setOnClickListener(v -> navigateToFragment(new accinfoFragment()));
        textView5.setOnClickListener(v -> navigateToFragment(new personal_profileFragment()));
        textView6.setOnClickListener(v -> navigateToFragment(new msgcenterFragment()));
        textView7.setOnClickListener(v -> navigateToFragment(new login_securityFragment()));
        textView8.setOnClickListener(v -> navigateToFragment(new data_privacyFragment()));


        return view;
    }

    // Helper method to navigate to the target fragment
    private void navigateToFragment(Fragment fragment) {
        requireActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment) // Replace 'fragment_container' with your container's ID
                .addToBackStack(null)
                .commit();
    }

}
