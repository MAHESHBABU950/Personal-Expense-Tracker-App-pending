package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.view.View;
import java.util.List;
import android.content.Intent;
import java.util.ArrayList;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.bottomappbar.BottomAppBar;

public class mainhomepage extends AppCompatActivity {

    private RecyclerView transactionRecyclerView;
    private TransactionAdapter transactionAdapter;
    private List<transaction> transactionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainhomepage);

        // Set up RecyclerView for transaction history
        transactionRecyclerView = findViewById(R.id.transaction_recycler_view);
        transactionRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the transaction list
        transactionList = new ArrayList<>();
        // Add sample data
        transactionList.add(new transaction("2025-01-12", "Grocery", 120.50));
        transactionList.add(new transaction("2025-01-13", "Rent", 500.00));
        transactionList.add(new transaction("2025-01-14", "Transport", 30.00));

        // Set up adapter for RecyclerView
        transactionAdapter = new TransactionAdapter(transactionList);
        transactionRecyclerView.setAdapter(transactionAdapter);

        // Set up FloatingActionButton to add expense
        FloatingActionButton fabAddExpense = findViewById(R.id.fab_add_expense);
        fabAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddExpense Activity (you can add this activity as needed)
                Intent intent = new Intent(mainhomepage.this, addexpenses.class);
                startActivity(intent);
            }
        });

        // Set up BottomNavigationView and BottomAppBar
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.btm_home) {
                    // Handle Home navigation
                    return true;
                } else if (item.getItemId() == R.id.btm_profile) {
                    // Handle Profile navigation
                    return true;
                }
                // Add other menu items as needed
                else {
                    return false;
                }
            }
        });


        BottomAppBar bottomAppBar = findViewById(R.id.bottomAppBar);
        bottomAppBar.setNavigationOnClickListener(view -> {
            // Handle BottomAppBar's navigation icon click
        });
    }
}
