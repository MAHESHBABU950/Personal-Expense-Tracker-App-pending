package com.example.my_personalexpensetracker_application;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log; // Import added for logging
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.button.MaterialButton;

public class main_loginpage1 extends AppCompatActivity {
    MaterialButton Loginbtn;
    TextView forgotPasswordTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_loginpage1);

        // Initialize the login button
        Loginbtn = findViewById(R.id.loginbtn);
        Loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Replace the container with mainhomepageFragment
                Intent intent = new Intent(main_loginpage1.this, mainhomepage.class);
                startActivity(intent);
                finish();
            }
        });

        // Initialize the "I forgot my password" TextView
        forgotPasswordTextView = findViewById(R.id.textview1);
        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(main_loginpage1.this, forgotpassword.class);
                startActivity(intent);
            }
        });
    }

    // Method to replace the container with a fragment
    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        if (findViewById(R.id.fragment_container) != null) {
            // If the container exists, replace it with the fragment
            transaction.replace(R.id.fragment_container, fragment);
            transaction.addToBackStack(null);
            transaction.commit();
        } else {
            // Log an error if the container is not found
            Log.e("FragmentTransaction", "Fragment container not found!");
        }
    }
}
