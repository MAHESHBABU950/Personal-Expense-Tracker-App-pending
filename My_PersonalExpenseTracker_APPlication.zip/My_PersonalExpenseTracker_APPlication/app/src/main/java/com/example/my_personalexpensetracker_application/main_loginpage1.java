package com.example.my_personalexpensetracker_application;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log; // Import added for logging
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.button.MaterialButton;

public class main_loginpage1 extends AppCompatActivity {
    MaterialButton Loginbtn;
    TextView forgotPasswordTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_loginpage1);

        // Initialize the login button
        Loginbtn = findViewById(R.id.loginbtn);
        Loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start the mainhomepage_btmnav Activity
                Intent intent = new Intent(main_loginpage1.this, mainhomepage_btmnav.class); // Correct activity name
                startActivity(intent);
                finish(); // Optional: Finish the current login activity
            }
        });

        // Initialize the "I forgot my password" TextView
        forgotPasswordTextView = findViewById(R.id.textview1);
        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to ForgotPassword activity
                Intent intent = new Intent(main_loginpage1.this, forgotpassword.class);
                startActivity(intent);
            }
        });
    }
}

