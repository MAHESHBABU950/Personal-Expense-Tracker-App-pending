package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.widget.ImageView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button button;
    ImageView imageviewlogo1;
    TextView textview1, textview2, textview3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageviewlogo1 = findViewById(R.id.imageView);
        textview1 = findViewById(R.id.textView1);
        textview2 = findViewById(R.id.textView2);
        textview3 = findViewById(R.id.textView3);

        // Set initial visibility to GONE
        imageviewlogo1.setVisibility(View.GONE);
        textview1.setVisibility(View.GONE);
        textview2.setVisibility(View.GONE);
        textview3.setVisibility(View.GONE);

        // Delay in milliseconds before showing the views
        long delayImageView = 1000;
        long delayTextView1 = 2000;
        long delayTextView2 = 3000;
        long delayTextView3 = 4000;
        long totalDelay = delayTextView3 + 1000; // Adding an extra second after the last view is shown

        // Show image view after delay
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                imageviewlogo1.setVisibility(View.VISIBLE);
            }
        }, delayImageView);

        // Show text view 1 after delay
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                textview1.setVisibility(View.VISIBLE);
            }
        }, delayTextView1);

        // Show text view 2 after delay
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                textview2.setVisibility(View.VISIBLE);
            }
        }, delayTextView2);

        // Show text view 3 after delay
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                textview3.setVisibility(View.VISIBLE);
            }
        }, delayTextView3);

        // Move to the next activity after all views are displayed
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, loginpage.class);
                startActivity(intent);
                finish(); // Close the current activity
            }
        }, totalDelay);
    }
}
