package com.example.my_personalexpensetracker_application;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class mainhomepageFragment extends Fragment {

    private ImageView notificationIcon;
    private RecyclerView transactionRecyclerView;
    private TransactionAdapter transactionAdapter;
    private List<transaction> transactionList;

    public mainhomepageFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_mainhomepage, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize the notification icon and set up the click listener
        notificationIcon = view.findViewById(R.id.notification_icon);

        notificationIcon.setOnClickListener(v -> {
            // Simulate receiving a notification. You can pass actual data here.
            String notificationTitle = "New Feature";
            String notificationMessage = "Check out the new analytics feature in the app.";

            // Create an Intent to navigate to the notifications page
            Intent intent = new Intent(requireActivity(), notifications.class);
            intent.putExtra("title", notificationTitle);
            intent.putExtra("message", notificationMessage);

            // Start the notifications activity
            startActivity(intent);
        });

        // Set up RecyclerView for transaction history
        transactionRecyclerView = view.findViewById(R.id.transaction_recycler_view);
        transactionRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Initialize the transaction list
        transactionList = new ArrayList<>();
        // Add sample data
        transactionList.add(new transaction("2025-01-12", "Grocery", 120.50));
        transactionList.add(new transaction("2025-01-13", "Rent", 500.00));
        transactionList.add(new transaction("2025-01-14", "Transport", 30.00));

        // Set up adapter for RecyclerView
        transactionAdapter = new TransactionAdapter(transactionList);
        transactionRecyclerView.setAdapter(transactionAdapter);
    }
}
