package com.example.my_personalexpensetracker_application;

public class Expenses {
    private String id;
    private String amount;
    private String category;
    private String description;

    public Expenses() {
        // Default constructor required for calls to DataSnapshot.getValue(Expense.class)
    }

    public Expenses(String id, String amount, String category, String description) {
        this.id = id;
        this.amount = amount;
        this.category = category;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}


