package com.example.my_personalexpensetracker_application;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class statisticsFragment extends Fragment {
    private LineChart expenseLineChart;

    public statisticsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_statistics, container, false);

        // Initialize LineChart
        expenseLineChart = view.findViewById(R.id.expenseLineChart);

        // Initialize Buttons
        Button dayButton = view.findViewById(R.id.dayButton);
        Button weekButton = view.findViewById(R.id.weekButton);
        Button monthButton = view.findViewById(R.id.monthButton);
        Button yearButton = view.findViewById(R.id.yearButton);

        // Set OnClickListeners for buttons
        dayButton.setOnClickListener(v -> updateChart("day"));
        weekButton.setOnClickListener(v -> updateChart("week"));
        monthButton.setOnClickListener(v -> updateChart("month"));
        yearButton.setOnClickListener(v -> updateChart("year"));

        // Initialize ImageView
        ImageView imageView10 = view.findViewById(R.id.imageView10);
        // Set the click listener for imageView10
        imageView10.setOnClickListener(v -> {
            mainhomepageFragment mainFragment = new mainhomepageFragment();
            getFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, mainFragment)
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }

    // Method to update chart data based on the selected time period
    private void updateChart(String timePeriod) {
        ArrayList<Entry> entries = new ArrayList<>();

        // Generate data based on the selected time period
        switch (timePeriod) {
            case "day":
                entries.add(new Entry(0f, 50f)); // Day 1
                entries.add(new Entry(1f, 80f)); // Day 2
                entries.add(new Entry(2f, 60f)); // Day 3
                break;

            case "week":
                entries.add(new Entry(0f, 300f)); // Week 1
                entries.add(new Entry(1f, 500f)); // Week 2
                entries.add(new Entry(2f, 400f)); // Week 3
                break;

            case "month":
                entries.add(new Entry(0f, 1200f)); // Month 1
                entries.add(new Entry(1f, 1500f)); // Month 2
                entries.add(new Entry(2f, 1300f)); // Month 3
                break;

            case "year":
                entries.add(new Entry(0f, 15000f)); // Year 1
                entries.add(new Entry(1f, 18000f)); // Year 2
                entries.add(new Entry(2f, 16000f)); // Year 3
                break;
        }

        // Create dataset and apply to chart
        LineDataSet dataSet = new LineDataSet(entries, "Expenses");
        dataSet.setColor(getResources().getColor(R.color.teal_200));
        dataSet.setCircleColor(getResources().getColor(R.color.purple_200));
        dataSet.setLineWidth(2f);
        dataSet.setValueTextSize(10f);

        LineData lineData = new LineData(dataSet);

        expenseLineChart.setData(lineData);
        expenseLineChart.invalidate(); // Refresh the chart
    }
}
