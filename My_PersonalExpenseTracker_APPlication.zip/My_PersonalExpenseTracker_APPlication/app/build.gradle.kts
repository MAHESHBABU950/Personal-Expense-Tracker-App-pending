plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.gms.google.services) // Correct syntax for using the plugin
}

android {
    namespace = "com.example.my_personalexpensetracker_application"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.my_personalexpensetracker_application"
        minSdk = 23 // Adjusted to match your provided code
        targetSdk = 33 // Adjusted to match your provided code
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    buildFeatures {
        viewBinding = false
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation(libs.firebase.auth)
    implementation("androidx.recyclerview:recyclerview:1.2.0")
    implementation("com.github.PhilJay:MPAndroidChart:3.1.0")
    implementation("com.google.firebase:firebase-messaging:23.1.0")
    implementation("com.google.android.material:material:1.9.0") // Use the latest version
    implementation("com.google.zxing:core:3.4.1") // QR code scanner
    //implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("androidx.activity:activity:1.6.1")
    implementation("androidx.fragment:fragment:1.5.5")
    implementation("com.google.firebase:firebase-auth:21.0.8")
    implementation(libs.firebase.database) // for transaction history activity
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
